require({cache:{
'url:epi-ecf-ui/widget/templates/GridFormView.html':"﻿﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-attach-point=\"formContainer\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/GridFormView", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/keys",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/dependency",
    "epi/shell/_ContextMixin",
    "epi/shell/ViewSettings",
// epi-cms
    "epi-cms/contentediting/_FormEditingMixin",
    "epi-cms/contentediting/ContentViewModel",
    "epi-cms/contentediting/CreateContent",
    "epi-cms/contentediting/MappingManager",
    "epi-cms/command/BackCommand",
    "epi-cms/command/NewContent",
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "./CampaignItemList",
    "../MarketingUtils",
    "./CommandButton",
    "./MarketingToolbar",
    "./_ConfirmDiscardChangesMixin",
    "../contentediting/GridFormContainer",
// resources
    "dojo/text!./templates/GridFormView.html",
    "epi/i18n!epi/nls/episerver.shared",
    "epi/i18n!epi/cms/nls/commerce.widget.gridformview"
], function (
// dojo
    array,
    declare,
    event,
    lang,
    aspect,
    domClass,
    domGeometry,
    keys,
    on,
    topic,
    when,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    dependency,
    _ContextMixin,
    ViewSettings,
// epi-cms
    _FormEditingMixin,
    ContentViewModel,
    CreateContent,
    MappingManager,
    BackCommand,
    NewContent,
    ContentReference,
// epi-ecf-ui
    CampaignItemList,
    MarketingUtils,
    CommandButton,
    MarketingToolbar,
    _ConfirmDiscardChangesMixin,
    GridFormContainer,
// resources
    template,
    sharedResources,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContextMixin, _FormEditingMixin, _ConfirmDiscardChangesMixin], {
        // tags:
        //      internal

        templateString: template,

        editLayoutContainer: {}, /* required object for _FormEditingMixin */

        // _isCreatingContent: bool
        //      Flag to indicate whether this screen is opened when creating a content
        //      or when editing.
        _isCreatingContent: false,

        _contentLightStore: null,

        _wrapperAspectHandlers: [],

        _invalidProperties: {},

        postCreate: function () {
            this.inherited(arguments);
            this._setupToolbar();
            this.formSettings = {
                baseClass: "epi-grid-form"
            };
            this._mappingManager = new MappingManager();
            this._contentLightStore = this._contentLightStore || dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
        },

        destroy: function () {
            this.inherited(arguments);

            if (this.viewModel) {
                this.viewModel.destroy();
                delete this.viewModel;
            }

            if (this._mappingManager) {
                this._mappingManager.clear();
                delete this._mappingManager;
            }

            this._removeEditorWrapperHandlers();
        },

        _setViewModelAttr: function (viewModel) {
            if (viewModel === this.viewModel) {
                return;
            }

            this._set("viewModel", viewModel);

            this.viewModel.own(
                topic.subscribe("/dnd/start", lang.hitch(this.viewModel, "beginOperation")),
                topic.subscribe("/dnd/stop", lang.hitch(this.viewModel, "endOperation")),
                this.viewModel.watch("hasPendingChanges", function (property, oldValue, newValue) {
                        if (Object.keys(this._invalidProperties).length === 0) {
                            this.toolbar.updateActionButtonStatus(this.toolbar.buttonNames.saveButton, newValue);
                        }
                }.bind(this))
            );
        },

        _setupToolbar: function () {
            var actionButtons = this.toolbar.getActionButtons();
            actionButtons.save.action = this._onSave.bind(this);
            actionButtons.close.action = this._onCancel.bind(this);

            this.toolbar.add([actionButtons.save, actionButtons.close]);
        },

        _onSave: function () {
            if (this.viewModel && !this.changesSaved()) {
                this.viewModel.save().then(function () {
                    this._publishUpdatedContent(this.viewModel);
                    
                    if(this._isEditingCampaign()) {
                        when(this._getChildPromotions()).then(function (promotions) {
                            promotions.forEach(function (item) {
                                this._contentLightStore.updateDependentStores(item);
                            }, this);
                        }.bind(this));
                    }                        
                }.bind(this));
            }
        },

        _getChildPromotions: function () {
            var queryOptions = this._getQueryOptions();
            var query = { 
                referenceId: this.viewModel.contentLink, 
                query: "getchildren" 
            };
            return this._contentLightStore.query(query, queryOptions);
        },

        _publishUpdatedContent: function (content) {
            topic.publish("/epi/cms/contentdata/updated", { contentLink: content.contentLink });
        },

        _getQueryOptions: function () {
            return {
                ignore: ["query"],
                comparers: {
                    "referenceId": function (queryValue, instance) {
                        return ContentReference.compareIgnoreVersion(queryValue, instance.parentLink);
                    }
                }
            };
        },

        _onCancel: function () {
            if (this._isEditingCampaign()) { // editing campaign, regarless creating or editing an existing
                // Go back to the campaign overview list
                this._openCampaignOverviewList();
                return;
            }

            if (this._isCreatingContent) { // creating discount
                // navigate to discount priority view in case of creating new discount
                this._openDiscountPriorityView();
                return;
            }

            // editing existing discount
            var backCommand = this._createBackCommand();
            if (backCommand.get("canExecute")) {
                backCommand.execute();
                return;
            }

            this._openCampaignOverviewList();
        },

        _openCampaignOverviewList: function () {
            topic.publish("/epi/shell/context/request", { uri: ViewSettings.settings.defaultContext }, { sender: this });
        },

        _openDiscountPriorityView: function () {
            var data = {
                sender: this, 
                backLink: { uri: "epi.cms.contentdata:///" + this.viewModel.contentData.parentLink }
            };
            topic.publish("/epi/shell/action/changeview", "discountpriorityview", {}, data);
        },

        _createBackCommand: function() {
            var backCommand = new BackCommand();
            backCommand.set("model", {});
            return backCommand;
        },

        changesSaved: function () {
            // summary:
            //      Indicates those changes are saved.
            // return:
            //      boolean
            // tags:
            //      protected
            return !this.viewModel.get("hasPendingChanges");
        },

        discardChanges: function () {
            // summary:
            //      Discard any changes.
            // tags:
            //      public

            //we need to reset the hasPendingChanges value here regardless of what it was before
            //otherwise the confirmbox will always appear
            this.viewModel.set("hasPendingChanges", false);

            //we are moving away from this view. We need to remove the handler for ctrl+s on
            //the body element
            if (this._keyboardSaveHandle) {
                this._keyboardSaveHandle.remove();
                this._keyboardSaveHandle = null;
            }
        },

        contextUpdated: function (ctx, callerData) {
            // summary:
            //    Called when the currently loaded view is updated.
            // tags:
            //    protected

            this._updateToolbarContext(ctx);
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this._isCreatingContent = !!(data && data.sender && data.sender instanceof CreateContent);

            this._updateToolbarContext(context);

            if (this.viewModel){
                this.viewModel.validator.clearErrorsBySource(this.viewModel.validator.validationSource.client);
                this.viewModel.validator.clearErrorsBySource(this.viewModel.validator.validationSource.server);
                this.viewModel.destroy();
            }
            this.set("viewModel", this._createViewModel(context.id));
            this.own(this.viewModel);
            //we set our keydown handler on entire body element to be able to capture "ctrl+s" even
            //when users has moved focus on something other than our form like a widget on a sidebar.
            this._keyboardSaveHandle = on(document.body, "keydown", this._onKeyDown.bind(this));

            this._removeEditorWrapperHandlers();

            return this._reloadViewModel();
        },

        _createViewModel: function(contentLink){
            return new ContentViewModel({
                contentLink: contentLink,
                local: true,
                contextTypeName: "epi.cms.contentdata",
                enableAutoSave: false
            });
        },

        _onKeyDown: function(e){
            if ((e.ctrlKey || e.metaKey) && String.fromCharCode(e.keyCode) === "S"){
                event.stop(e);
                this._onSave();
            }
        },

        _reloadViewModel: function() {
            // we refresh before loading the viewModel because we want to make sure that we dont get cached data here
            return this.viewModel.contentDataStore.refresh(this.viewModel.contentLink)
                .then(function() {
                    this.viewModel.reload().then(function(){
                        this.onReadySetupEditMode();
                    }.bind(this));
                }.bind(this));
        },

        placeForm: function(form){
            form.placeAt(this.formContainer);
            this.layout();
        },

        removeForm: function(form){
            return true;
        },

        _onWrapperValueChange: function (wrapper, value, oldValue) {
            var mapping = this._mappingManager.findOne("wrapper", wrapper),
                propertyName = mapping.propertyName;

            // Since we are saving a new value for the property, remove any marker for invalid value, since the old value is obsolete
            if (this._invalidProperties[propertyName]) {
                delete this._invalidProperties[propertyName];
            }

            this.viewModel.setProperty(propertyName, value, oldValue);
        },

        _onWrapperStopEdit: function (wrapper, value, oldValue, implicitExit) {
            // _FormEditingMixin required property
        },

        _onWrapperCancel: function (wrapper, implicitExit) {
            // _FormEditingMixin required property
        },

        onSetupEditModeComplete: function(){
            // _FormEditingMixin required property
            if (this._isEditingCampaign()) {
                this._form.containerLayout.set("header", resources.campaignformheading);

                var layout = new GridFormContainer({
                    name: "",
                    title: resources.campaigndiscountsheading,
                    hasOwnRow: true
                });

                layout.addChild(this._createDiscountButton());
                layout.addChild(this._createDiscountList());

                this._form.containerLayout.addChild(layout);
                this.own(layout);
            } else {
                this._form.containerLayout.set("header", resources.discountformheading);
            }
            this._currentGroup = null;

            this._addEditorWrapperHandlers();
        },

        _createDiscountButton: function () {

            var createDiscountCommand = new NewContent({
                contentType: MarketingUtils.contentTypeIdentifier.promotionData,
                label: resources.newdiscountlabel
            });

            var commandModel = lang.mixin({
                //default to true to make button executable (the canExecute of createDiscountCommand should return true)
                hasTranslationAccess: true,
                isPreferredLanguageAvailable: true
            }, this.viewModel.contentData);

            createDiscountCommand.set("model", commandModel);

            var button = new CommandButton({
                model: createDiscountCommand
            });

            button.set("iconClass", "epi-iconPlus");
            this.own(button);

            return button;
        },

        _createDiscountList: function () {
            var campaignItemList = new CampaignItemList({
                withDeleteButton: true,
                excludeFacets: true
            });
            domClass.add(campaignItemList.grid.domNode, "epi-grid--with-border epi-grid-height--auto epi-dgrid__promotionlist--with-no-redemptions");
            this.own(campaignItemList);
            return campaignItemList;
        },

        onGroupCreated: function(groupName, widget, parentGroupWidget) {
            this.inherited(arguments);
            this._currentGroup = widget;
        },

        onFieldCreated: function(fieldName, widget) {
            this.inherited(arguments);
            this._resizeNameField(fieldName, widget);
            this._resizeWidget(widget);
        },

        _resizeNameField: function (fieldName, widget) {
            // summary:
            //      Add the css class epi-input--full-width to the name field
            //      in order to make it as wide as a long string property
            // tags:
            //      internal

            if (fieldName === "icontent_name") {
                domClass.add(widget.domNode, "epi-input--full-width");
            }
        },

        _resizeWidget: function(widget){
            // summary:
            //      This makes sure that some editors that define width
            //      in code (XHtml and Longstring properties) does not
            //      become to wide
            // tags:
            //      internal

            var fullWidthParent = this._currentGroup ? this._currentGroup.hasOwnRow : true;
            if (fullWidthParent){
                return;
            }
            /*  this will fix widgets that sets a width property.
                IE TinyMCEEditors for xhtml strings */
            if (widget.width > 470){
                widget.set("width", 470);
            }
            /*  this is a special case for PropertyLongstring
                that is needed because it hardcodes it's style
                to be width:582px; to match xhtml strings :'(
                see: https://stash.ep.se/projects/SH/repos/episerver-ui/browse/EPiServer.Cms.Shell.UI/UI/ObjectEditing/EditorDescriptors/LongStringEditorDescriptor.cs?until=1df13a6315b120175b5755814ae2f280ec519d38#24
            */
            if (widget.style === "width:582px;"){
                widget.set("style", "width:472px;");
            }
        },

        layout: function () {
            // summary:
            //      Layout the children widgets.
            // tags:
            //      protected

            if (this._form){
                var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);

                // Set the size of the form to be the content height minus the toolbar height.
                this._form.resize({
                    h: this._contentBox.h - toolbarSize.h,
                    w: this._contentBox.w
                });
            }
        },

        _isEditingCampaign: function(){
            return MarketingUtils.isSalesCampaign(this.viewModel.contentData.typeIdentifier);
        },

        _updateToolbarContext: function (context) {
            this.toolbar.update({
                currentContext: context
            });
        },

        _removeEditorWrapperHandlers: function () {
            if (this._wrapperAspectHandlers && this._wrapperAspectHandlers.length > 0) {
                this._wrapperAspectHandlers.forEach(function (handler) {
                    handler.remove();
                });
                this._wrapperAspectHandlers = [];
            }

            this._invalidProperties = {};
        },

        _addEditorWrapperHandlers: function () {
            this._mappingManager.find().forEach(function (mapping) {
                var propertyName = mapping.propertyName;
                this._wrapperAspectHandlers.push(aspect.after(mapping.wrapper, "_onTryToStopWithInvalidValue", function () {
                    // This is called whenever an editor is invalid. So disable the save button and keep a marker that the property is invalid.
                    this.toolbar.updateActionButtonStatus(this.toolbar.buttonNames.saveButton, false);
                    this._invalidProperties[propertyName] = true;
                }.bind(this)));
            }, this);
        }
    });
});