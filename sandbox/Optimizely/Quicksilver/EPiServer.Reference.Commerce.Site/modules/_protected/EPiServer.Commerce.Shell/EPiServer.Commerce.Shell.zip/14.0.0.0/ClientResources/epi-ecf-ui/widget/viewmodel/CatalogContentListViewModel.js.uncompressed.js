﻿define("epi-ecf-ui/widget/viewmodel/CatalogContentListViewModel", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Evented",
    "dojo/when",

    // epi
    "epi/shell/selection",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/DelegateCommand",
    "epi/shell/command/ToggleCommand",

    // epi-cms
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/NewContent",
    "epi-cms/command/CopyContent",
    "epi-cms/command/CutContent",
    "epi-cms/command/DeleteContent",
    "epi-cms/core/ContentReference",

    // commerce
    "../../command/DetachFromCategory",
    "../../command/PasteCatalogContent",
    "../../component/DeleteCatalogContentHandler",
    "../../contentediting/ModelSupport",
    "epi-ecf-ui/widget/viewmodel/CatalogListViewModel",

    // resources
    "epi/i18n!epi/cms/nls/commerce.widget.catalogcontentlist",
    "epi/i18n!epi/nls/episerver.shared"
], function (
    // dojo
    array,
    declare,
    lang,
    Evented,
    when,

    // epi
    Selection,
    withConfirmation,
    DelegateCommand,
    ToggleCommand,

    // epi-cms
    ChangeContextCommand,
    NewContent,
    CopyCommand,
    CutCommand,
    DeleteCommand,
    ContentReference,

    // commerce
    DetachFromCategory,
    PasteCatalogContent,
    DeleteCatalogContentHandler,
    ModelSupport,
    CatalogListViewModel,

    // resources
    resources,
    sharedresources
) {
        return declare([CatalogListViewModel, Evented], {

            res: resources,

            sortMode: false,

            showThumbnails: true,

            getSelectionCommands: function () {
                return [
                    this._commandRegistry.cut.command,
                    this._commandRegistry.copy.command,
                    this._commandRegistry.pasteOnContext.command,
                    this._commandRegistry.detach.command,
                    this._commandRegistry.remove.command,
                    this._commandRegistry.toggleSortMode.command
                ];
            },

            getCommand: function (commandName) {
                // summary:
                //      Gets a command by command name.
                // tags:
                //      public

                return this._commandRegistry[commandName] ? this._commandRegistry[commandName].command : null;
            },

            setCommandAvailability: function (parameter) {
                var commandRegistry = this._commandRegistry;
                var isDefaultMode = !this.sortMode;
                var isFirstItem = (parameter != null && parameter.isFirstItem);
                var isLastItem = (parameter != null && parameter.isLastItem);

                commandRegistry.moveup.command.set("isAvailable", !isDefaultMode);
                commandRegistry.movedown.command.set("isAvailable", !isDefaultMode);

                this._setCanExecute(commandRegistry.moveup.command, !isDefaultMode && !isFirstItem);
                this._setCanExecute(commandRegistry.movedown.command, !isDefaultMode && !isLastItem);
                this._setAvailability(commandRegistry.edit.command, isDefaultMode);
                this._setAvailability(commandRegistry.popupCommand.command, isDefaultMode);
                this._setAvailability(commandRegistry.paste.command, isDefaultMode);
                this._setAvailability(commandRegistry.copy.command, isDefaultMode);
                this._setAvailability(commandRegistry.cut.command, isDefaultMode);
                this._setAvailability(commandRegistry.pasteOnContext.command, isDefaultMode);
                this._setAvailability(commandRegistry.detach.command, isDefaultMode);
                this._setAvailability(commandRegistry.remove.command, isDefaultMode);
            },

            _setCanExecute: function (command, validCondition) {
                command.set("canExecute", validCondition);
            },

            _setAvailability: function (command, validCondition) {
                command.set("isAvailable", validCondition);
            },

            moveItem: function (sourceContent, targetContent, moveBefore) {

                var query = {
                    referenceId: this.model.contextId,
                    requestMode: ModelSupport.relationRequestMode.byTarget,
                    relationTypes: [
                        ModelSupport.relationType.node]
                };
                
                return when(this.treeStoreModel.relationStore.query(query)).then(function (relations) {
                    var sourceRelation;
                    var targetRelation;

                    array.forEach(relations, function (relation) {
                        if (ContentReference.compareIgnoreVersion(sourceContent.contentLink, relation.source)) {
                            sourceRelation = relation;
                        }

                        if (!targetContent) { // No target content happens when an item is dropped after the list. In that case we want to use the last item in the list as target.
                            targetRelation = relation;
                        } else if (ContentReference.compareIgnoreVersion(targetContent.contentLink, relation.source)) {
                            targetRelation = relation;
                        }
                    }.bind(this));

                    if (moveBefore) {
                        sourceRelation.sortOrder = targetRelation.sortOrder;
                    } else {
                        sourceRelation.sortOrder = targetRelation.sortOrder + 1;
                    }

                    return this.treeStoreModel.relationStore.put(sourceRelation);

                }.bind(this));
            },

            _setupCommands: function () {

                var commandSettings = {
                    category: "context",
                    clipboard: this.clipboardManager,
                    selection: this.selection,
                    model: this.treeStoreModel
                };

                var toolbarGroupSettings = lang.mixin({ toolbarGroup: "clipboard" }, commandSettings);
                var deleteCommand = new DeleteCommand(lang.mixin({ model: this.treeStoreModel, toolbarGroup: "misc" }, commandSettings));

                lang.mixin(this._commandRegistry, this.getCreateCommands());
                lang.mixin(this._commandRegistry, {
                    edit: {
                        command: new ChangeContextCommand({
                            category: "context",
                            forceContextChange: true,
                            viewName: "formedit"
                        }),
                        order: -1
                    },
                    cut: {
                        command: new CutCommand(toolbarGroupSettings),
                        order: 101
                    },
                    copy: {
                        command: new CopyCommand(toolbarGroupSettings),
                        order: 102
                    },
                    paste: {
                        command: new PasteCatalogContent(commandSettings),
                        order: 103
                    },
                    pasteOnContext: {
                        command: new PasteCatalogContent(lang.mixin(toolbarGroupSettings, { selection: new Selection() }))
                    },
                    detach: {
                        command: withConfirmation(new DetachFromCategory(lang.mixin(commandSettings, { toolbarGroup: "misc" })), null, {
                            title: this.res.detachconfirmation.title,
                            description: this.res.detachconfirmation.description
                        }),
                        order: 104
                    },
                    remove: {
                        command: withConfirmation(deleteCommand, DeleteCatalogContentHandler, {
                            title: this.res.deleteconfirmation.title,
                            description: this.res.deleteconfirmation.description,
                            confirmActionText: sharedresources.action.deletelabel,
                            cancelActionText: sharedresources.action.cancel
                        }),
                        order: 105
                    },
                    toggleSortMode: {
                        command: new ToggleCommand({
                            model: this,
                            toolbarGroup: "sorting",
                            property: "sortMode",
                            iconClass: "epi-iconSort",
                            label: this.res.sorting.sortmode
                        }),
                        order: 106
                    },
                    toggleThumbnails: {
                        command: new ToggleCommand({
                            model: this,
                            property: "showThumbnails"
                        }),
                        order: 107
                    },
                    moveup: {
                        command: new DelegateCommand(lang.mixin({
                            name: "moveup",
                            isAvailable: false,
                            canExecute: true,
                            label: this.res.sorting.contextmenu.moveup,
                            iconClass: "epi-iconUp",
                            delegate: function (cmd) {
                                this.emit("onMoveUp");
                            }.bind(this)
                        }, commandSettings)),
                        order: 108
                    },
                    movedown: {
                        command: new DelegateCommand(lang.mixin({
                            name: "movedown",
                            isAvailable: false,
                            canExecute: true,
                            label: this.res.sorting.contextmenu.movedown,
                            iconClass: "epi-iconDown",
                            delegate: function (cmd) {
                                this.emit("onMoveDown");
                            }.bind(this)
                        }, commandSettings)),
                        order: 109
                    }
                });
                this.set("commands", this._commandRegistry.toArray());
            },

            _sortModeSetter: function (value) {
                this.sortMode = value;

                this.setCommandAvailability();
            }
        });
    });