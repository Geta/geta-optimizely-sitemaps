//>>built
define("epi-ecf-ui/widget/CommandButton",["dojo/_base/declare","dijit/form/Button","epi/shell/command/_CommandModelBindingMixin"],function(_1,_2,_3){return _1([_2,_3]);});